package modulo.evaluacion;

public interface Asesoria {
	public void analizarUsuario();

}
